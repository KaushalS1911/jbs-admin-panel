import { atom } from "recoil";

export const config = atom({
    key: "config",
    default: {},
});


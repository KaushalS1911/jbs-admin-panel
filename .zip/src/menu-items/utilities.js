import {userMenu} from "./constants";


const utilities = {
  id: "utilities",
  type: "group",
  children: userMenu
};

export default utilities;
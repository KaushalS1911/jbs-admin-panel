import { useRoutes } from 'react-router';
import Routes from './Routes';


export default function ThemeRoutes() {
  return useRoutes([Routes]);
}

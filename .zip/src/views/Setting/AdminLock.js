import React from "react";

function AdminLock() {
  return <div>AdminLock</div>;
}

export default AdminLock;


import Batch from 'views/Batches/Batch';

const Batches = () => (
    < >
        <Batch />
    </>
);

export default Batches;



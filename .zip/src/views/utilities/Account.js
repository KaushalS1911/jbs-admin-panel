import Mainbreadcrumbs from "contants/Mainbreadcrumbs";
import MainAccount from "views/Account/MainAccount";

const Account = () => (
    <>
        <Mainbreadcrumbs title={"Account"} />
        <MainAccount />
    </>
);
export default Account;

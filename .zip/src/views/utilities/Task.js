import Index from 'views/tasks/index';

const Task = () => {
  return (
    <>
    <Index/>
    </>
  )
}

export default Task
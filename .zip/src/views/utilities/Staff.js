import Index from 'views/Employee/Employee';

const Staff = () => (
  <>
    <Index />
  </>
);

export default Staff;

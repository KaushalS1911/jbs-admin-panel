
import Mainbreadcrumbs from 'contants/Mainbreadcrumbs';
import Index from 'views/Demo';

// ==============================|| TYPOGRAPHY ||============================== //

const Demo = () => (
  <>
    <Mainbreadcrumbs title={"Demo"} />
    <Index />
  </>
);

export default Demo;

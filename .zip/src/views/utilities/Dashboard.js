import React from 'react';
import Dashboard from '../dashboard/Default/index';

const DashboardComponent = () => {
  return (
    <>
      <Dashboard />
    </>
  );
};

export default DashboardComponent;

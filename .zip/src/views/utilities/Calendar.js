import CalendarApp from 'views/calendar/CalendarApp';

const calendar = () => {
  return (
    <>
    <CalendarApp/>
    </>
  )
}

export default calendar
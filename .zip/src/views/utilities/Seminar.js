
import Index from 'views/Seminars/Index';
const Seminar = () => (
  <>
    <Index/>
  </>
);

export default Seminar;

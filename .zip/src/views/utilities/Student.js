// import MainCard from 'ui-component/cards/MainCard';
import Index from 'views/Student/Index.js'
import { Box } from '@mui/material'

const Student = () => (
  <Box>
    <div>
      <Index />
    </div>
  </Box>
)

export default Student

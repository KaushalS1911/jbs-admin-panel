import Index from '../inquiry/Inquiry';

const Inquiry = () => (
  <>
    <Index />
  </>
);

export default Inquiry;